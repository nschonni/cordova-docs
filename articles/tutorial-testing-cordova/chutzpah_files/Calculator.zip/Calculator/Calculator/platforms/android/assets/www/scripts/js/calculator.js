function Calculator() {
}

Calculator.prototype.add = function (num1, num2) {
    return num1 + num2;
}

Calculator.prototype.subtract = function (num1, num2) {
    return num1 - num2;
}

Calculator.prototype.divide = function (num1, num2) {
    return num1 / num2;
}

Calculator.prototype.multiply = function (num1, num2) {
    return num1 * num2;
}