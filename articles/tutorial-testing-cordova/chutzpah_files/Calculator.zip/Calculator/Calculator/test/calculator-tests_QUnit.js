﻿/*
QUnit.module("Calculator QUnit");

var calculator = new Calculator();

test('can add', function () {
    equal(calculator.add(5, 5), 10);
});

test('can subtract', function () {
    equal(calculator.subtract(5, 5), 0);
});

test('can divide', function () {
    equal(calculator.divide(5, 5), 1);
});

test('can multiply', function () {
    equal(calculator.multiply(5, 5), 25);
});
*/